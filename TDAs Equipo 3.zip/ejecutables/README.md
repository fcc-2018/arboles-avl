
### Ejecutables

#### Windows 64 bits

  -  arbolAVL.exe 
   
compilado g++.exe (MinGW.org GCC-8.2.0-3) 8.2.0

#### Linux 64 bits

  - arbolAVL 

compilado con: g++ (Debian 6.3.0-18+deb9u1) 6.3.0 20170516
